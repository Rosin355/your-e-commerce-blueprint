// Fase 2D.6 — Tipi condivisi Admin V2 / AI.
// Modulo puro: nessuna dipendenza Deno, Shopify o pipeline legacy.

export type AppRole =
  | "admin"
  | "tech_admin"
  | "publisher"
  | "editor"
  | "moderator"
  | "user";

export type ReadAction =
  | "list_products"
  | "get_product"
  | "get_field_definitions"
  | "get_product_history"
  | "get_source_baseline"
  | "validate_field_update"
  | "get_admin_context"
  | "get_dashboard_stats";

export type CommandAction =
  | "update_field"
  | "clear_field"
  | "confirm_legacy_value"
  | "reject_legacy_value"
  | "sync_field";

export type ApiAction = ReadAction | CommandAction;

export type ApiErrorCode =
  | "UNAUTHENTICATED"
  | "FORBIDDEN"
  | "NOT_FOUND"
  | "FIELD_NOT_EDITABLE"
  | "VALIDATION_ERROR"
  | "VERSION_CONFLICT"
  | "IDEMPOTENCY_CONFLICT"
  | "REVIEW_STATE_INVALID"
  | "NO_CHANGE"
  | "WRITES_DISABLED"
  | "BLOCK_SYNC"
  | "STATE_DRIFT"
  | "SYNC_VERIFY_FAILED"
  | "SHOPIFY_WRITE_FAILED"
  | "INTERNAL_ERROR";

export interface AuthContext {
  userId: string;
  roles: AppRole[];
  catalogApproval?: { action: string; target: string; before: Record<string, unknown> };
  catalogGrant?: { enabled: boolean; capabilities: string[]; fieldKeys: string[] };
}

export interface FieldDefinition {
  key: string;
  label: string;
  field_group: string;
  editor_type: string;
  data_type: "text" | "number" | "boolean" | "json" | "array";
  visible: boolean;
  editable: boolean;
  ai_allowed: boolean;
  manual_only: boolean;
  publishable: boolean;
  required: boolean;
  protected_on_reimport: boolean;
  applies_to: "product" | "variant" | "both";
  sort_order: number;
  help_text: string | null;
  validation_rules: Record<string, unknown>;
  shopify_mapping?: Record<string, unknown>;
  review_policy: string;
}

export interface CurrentValueRow {
  id: string;
  product_id: string;
  sku: string;
  field_key: string;
  entity_type: string;
  value_text: string | null;
  value_number: number | null;
  value_json: unknown | null;
  value_origin: string;
  origin: string;
  review_status: string;
  publish_blocked: boolean;
  protected_on_reimport: boolean;
  source_snapshot_id: string | null;
  is_locked: boolean;
  publish_state?: "draft" | "pending_publish" | "published" | "failed";
  shopify_verified_value?: unknown | null;
  shopify_verified_at?: string | null;
  shopify_sync_error_code?: string | null;
  shopify_sync_error_message?: string | null;
  version: number;
  updated_at: string;
}

export interface SourceSnapshotRow {
  id: string;
  product_id: string | null;
  normalized: Record<string, unknown>;
  created_at: string;
}

export interface ListProductsFilters {
  search?: string;
  sku?: string;
  gtin?: string;
  entityType?: "simple" | "variable" | "variation";
  category?: string;
  reviewRequired?: boolean;
  publishBlocked?: boolean;
  completeness?: "complete" | "incomplete";
  origin?: string;
  productSource?: string;
  needsClassification?: boolean;
}

export interface ListProductsRequest extends ListProductsFilters {
  groupFamilies?: boolean;
  cursor?: string | null;
  pageSize?: number;
}

export interface CommandRequest {
  productId: string;
  fieldKey: string;
  value?: unknown;
  expectedVersion?: number;
  idempotencyKey?: string;
  confirm?: boolean;
}
