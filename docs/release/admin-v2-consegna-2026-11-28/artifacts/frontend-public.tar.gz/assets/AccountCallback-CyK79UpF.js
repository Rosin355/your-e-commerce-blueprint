import{j as s}from"./index-kMoBF-yp.js";import{S as o,C as t,a,H as r}from"./CustomerPages-BquggWNg.js";function c(){return o?s.jsx(t,{children:s.jsx(a,{})}):s.jsx(r,{})}export{c as default};
