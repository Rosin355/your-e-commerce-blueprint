import{j as o}from"./index-kMoBF-yp.js";import{S as s,C as t,b as r,H as u}from"./CustomerPages-BquggWNg.js";function a(){return s?o.jsx(t,{children:o.jsx(r,{})}):o.jsx(u,{})}export{a as default};
