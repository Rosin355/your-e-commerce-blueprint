import{j as s}from"./index-kMoBF-yp.js";import{S as t,C as o,c as r,H as u}from"./CustomerPages-BquggWNg.js";function m(){return t?s.jsx(o,{children:s.jsx(r,{})}):s.jsx(u,{})}export{m as default};
