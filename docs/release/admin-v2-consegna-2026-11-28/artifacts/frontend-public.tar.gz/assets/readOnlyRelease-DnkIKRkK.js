const A=!1,E="admin-delivery-20261121-r2";export{E as A,A as a};
