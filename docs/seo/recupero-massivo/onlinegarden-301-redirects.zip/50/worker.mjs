const hosts = new Set(['onlinegarden.it', 'www.onlinegarden.it']);
const legacyPath = /^\/prodotto\/(?:[a-z0-9-]+\/)+$/;
const destinationUrl = /^https:\/\/onlinegarden\.it\/products\/[a-z0-9]+(?:-[a-z0-9]+)*$/;
const utm = new Set(['utm_source', 'utm_medium', 'utm_campaign', 'utm_term', 'utm_content']);

function respond(request, findTarget) {
  if (request.method !== 'GET' && request.method !== 'HEAD') return null;
  const url = new URL(request.url);
  if (!['http:', 'https:'].includes(url.protocol) || !hosts.has(url.host) || !legacyPath.test(url.pathname)) return null;
  const destination = findTarget(url.pathname);
  if (!destination) return null;
  const target = new URL(destination);
  for (const [key, value] of url.searchParams) {
    if (key === 'attribute_dimensioni') continue;
    if (!utm.has(key)) return null;
    target.searchParams.append(key, value);
  }
  return new Response(null, {status: 301, headers: {Location: target.href, 'Cache-Control': 'no-store'}});
}

// Il manifest storico conserva i gate originali per i chiamanti della PR #82.
export function redirectResponse(request, manifest) {
  if (manifest?.enabled !== true || !manifest.approvalReference?.trim?.() || !Array.isArray(manifest.rules)) return null;
  return respond(request, path => {
    const matches = manifest.rules.filter(rule => rule?.oldPath === path);
    if (matches.length !== 1) return null;
    const [rule] = matches;
    return rule.reviewApproved === true && rule.confidence === 'HIGH' && rule.qaStatus === 'PASS' &&
      rule.destinationStatus === 200 && destinationUrl.test(rule.newUrl) ? rule.newUrl : null;
  });
}

export function createHandler(manifest, originFetch = fetch) {
  return {fetch(request) { return redirectResponse(request, manifest) ?? originFetch(request); }};
}

// Le coppie vengono validate una sola volta all'avvio dell'isolato.
export function createMappedHandler(pairs, originFetch = fetch) {
  const lookup = new Map();
  for (const [path, target] of pairs) {
    if (!legacyPath.test(path) || !destinationUrl.test(target) || lookup.has(path)) throw Error('Mapping non valido o duplicato: ' + path);
    lookup.set(path, target);
  }
  return {fetch(request) { return respond(request, path => lookup.get(path)) ?? originFetch(request); }};
}

export default createMappedHandler([["/prodotto/rose/rosa-jasmina-rampicante/","https://onlinegarden.it/products/rosa-jasmina-rampicante"],["/prodotto/piante-da-interno/grasse-e-succulente/agave-americana-verde/","https://onlinegarden.it/products/agave-americana-verde"],["/prodotto/piante-da-interno/piante-da-appartamento/kalanchoe-calandiva-bianco/","https://onlinegarden.it/products/kalanchoe-calandiva-bianco"],["/prodotto/piante-da-interno/grasse-e-succulente/kalanchoe-tetraphylla/","https://onlinegarden.it/products/kalanchoe-tetraphylla-kalanchoe-a-quattro-foglie"],["/prodotto/da-frutto/castanea-sativa-marrone-di-marradi-castagno-marrone/","https://onlinegarden.it/products/castanea-sativa-marrone-di-marradi-castagno-marrone"],["/prodotto/da-frutto/prunus-avium-lapins-ciliegio/","https://onlinegarden.it/products/prunus-avium-lapins-ciliegio"],["/prodotto/piante-da-esterno/arbusti/calycanthus-floridus-calicanto-estivo/","https://onlinegarden.it/products/calycanthus-floridus-calicanto-estivo"],["/prodotto/piante-da-esterno/arbusti/calycanthus-venus-calicanto-estivo/","https://onlinegarden.it/products/calycanthus-venus-calicanto-estivo"],["/prodotto/piante-da-esterno/arbusti/rhyncospermum-asiaticum-tricolor-gelsomino/","https://onlinegarden.it/products/rhyncospermum-asiaticum-tricolor-gelsomino"],["/prodotto/piante-da-esterno/arbusti/elaeagnus-ebbingei-aurea-eleagno/","https://onlinegarden.it/products/elaeagnus-ebbingei-aurea-eleagno"],["/prodotto/piante-da-esterno/alberi/fagus-sylvatica-dawyck-purple-faggio/","https://onlinegarden.it/products/fagus-sylvatica-dawyck-purple-faggio"],["/prodotto/piante-da-esterno/alberi/ginkgo-biloba-mariken/","https://onlinegarden.it/products/ginkgo-biloba-mariken-albero-nano-da-giardino-e-terrazzo"],["/prodotto/piante-da-esterno/alberi/ginkgo-biloba-menhir/","https://onlinegarden.it/products/ginkgo-biloba-menhir-lalbero-antico-dal-portamento-elegante"],["/prodotto/piante-da-esterno/arbusti/parrotia-persica-bella-albero-pagoda/","https://onlinegarden.it/products/parrotia-persica-bella-albero-pagoda"],["/prodotto/piante-da-esterno/alberi/paulownia-tomentosa-paulonia/","https://onlinegarden.it/products/paulownia-tomentosa-paulonia"],["/prodotto/piante-da-interno/piante-da-appartamento/tradescantia-nanouk/","https://onlinegarden.it/products/tradescantia-nanouk"],["/prodotto/acquatiche/ninfee/nymphaea-amabilis-ninfea/","https://onlinegarden.it/products/nymphaea-amabilis-ninfea-rosa-per-laghetti"],["/prodotto/acquatiche/ninfee/nymphaea-atro-purpurea-ninfea/","https://onlinegarden.it/products/nymphaea-atro-purpurea-ninfea-a-fiori-porpora-scuro"],["/prodotto/acquatiche/ninfee/nymphaea-dahlia-ninfea/","https://onlinegarden.it/products/nymphaea-dahlia-ninfea-rosa-da-laghetto"],["/prodotto/acquatiche/ninfee/nymphaea-joey-tomocick-ninfea/","https://onlinegarden.it/products/nymphaea-joey-tomocick-ninfea-giallo-rosa-per-laghetto"],["/prodotto/acquatiche/ninfee/nymphaea-mary-patricia-ninfea/","https://onlinegarden.it/products/nymphaea-mary-patricia-ninfea-rosa-a-fioritura-notturna"],["/prodotto/acquatiche/piante-palustri/acorus-gramineus-ogon-calamo/","https://onlinegarden.it/products/acorus-gramineus-ogon-calamo"],["/prodotto/aromatiche/helichrysum-italico-pianta-liquirizia/","https://onlinegarden.it/products/helichrysum-italico-pianta-liquirizia"],["/prodotto/aromatiche/laurus-nobilis-alloro-ciliegio/","https://onlinegarden.it/products/laurus-nobilis-alloro-ciliegio"],["/prodotto/aromatiche/lavandula-angustifolia-lavanda-officinale/","https://onlinegarden.it/products/lavandula-angustifolia-lavanda-officinale"],["/prodotto/aromatiche/maggiorana-origanum-majorana/","https://onlinegarden.it/products/maggiorana-origanum-majorana"],["/prodotto/aromatiche/menta-dellimperatore-mentha/","https://onlinegarden.it/products/menta-dellimperatore-mentha"],["/prodotto/aromatiche/menta-mojito-mentha/","https://onlinegarden.it/products/menta-mojito-mentha"],["/prodotto/aromatiche/origano-officinale-origanum-officinalis/","https://onlinegarden.it/products/origano-officinale-origanum-officinalis"],["/prodotto/aromatiche/rosmarinus-officinalis-rosmarino/","https://onlinegarden.it/products/rosmarinus-officinalis-rosmarino"],["/prodotto/aromatiche/salvia-officinalis-salvia-a-foglia-stretta/","https://onlinegarden.it/products/salvia-officinalis-salvia-a-foglia-stretta"],["/prodotto/bulbi/amaryllis/amaryllis-belladonna/","https://onlinegarden.it/products/amaryllis-belladonna-bulbo-di-alta-qualita-1-pezzo"],["/prodotto/bulbi/amaryllis/amaryllis-ginevra/","https://onlinegarden.it/products/bulbo-di-amaryllis-ginevra-fiori-doppi-spettacolari"],["/prodotto/bulbi/amaryllis/amaryllis-host/","https://onlinegarden.it/products/amaryllis-host-bulbo-da-fiore-doppio"],["/prodotto/bulbi/amaryllis/amaryllis-scarlet/","https://onlinegarden.it/products/amaryllis-scarlet-bulbo-di-alta-qualita-per-fioritura-invernale"],["/prodotto/bulbi/dalie/dalia-amy-white/","https://onlinegarden.it/products/dalia-amy-white-bulbo-di-alta-qualita"],["/prodotto/bulbi/dalie/dalia-bloodgood/","https://onlinegarden.it/products/dalia-bloodgood-tubero-per-fioriture-rosso-intenso"],["/prodotto/bulbi/dalie/dalia-california/","https://onlinegarden.it/products/dalia-california-dahlia-pinnata-bulbi-di-alta-qualita"],["/prodotto/bulbi/dalie/dalia-glory/","https://onlinegarden.it/products/dalia-glory-bulbi-da-fiore-per-grandi-fioriture-estive"],["/prodotto/bulbi/dalie/dalia-krimson/","https://onlinegarden.it/products/dalia-krimson-bulbo-di-dalia-a-fiori-rossi-doppi"],["/prodotto/bulbi/dalie/dalia-naomy/","https://onlinegarden.it/products/dalia-naomy-bulbi-da-fiore-per-giardini-e-balconi-eleganti"],["/prodotto/bulbi/dalie/dalia-pink-leaf/","https://onlinegarden.it/products/dalia-pink-leaf-bulbo-di-alta-qualita"],["/prodotto/bulbi/dalie/dalia-pompon-arancio/","https://onlinegarden.it/products/dalia-pompon-arancio-bulbi-di-alta-qualita"],["/prodotto/bulbi/dalie/dalia-pompon-purple/","https://onlinegarden.it/products/dalia-pompon-purple-bulbo-da-fiore-1-pezzo"],["/prodotto/bulbi/dalie/dalia-pompon-rosso/","https://onlinegarden.it/products/dalia-pompon-rosso-bulbi-di-alta-qualita"],["/prodotto/bulbi/dalie/dalia-red-carpet/","https://onlinegarden.it/products/dalia-red-carpet-bulbi-di-dalia-nana-a-fiore-rosso"],["/prodotto/bulbi/dalie/dalia-red-king/","https://onlinegarden.it/products/bulbo-di-dalia-red-king-fiori-rossi-grandi"],["/prodotto/bulbi/dalie/dalia-red-robin-spinosa/","https://onlinegarden.it/products/dalia-red-robin-spinosa-bulbi-da-fiore-rossi-vivaci"],["/prodotto/bulbi/dalie/dalia-royal-red/","https://onlinegarden.it/products/dalia-royal-red-bulbo-da-fiore-rosso-intenso"],["/prodotto/bulbi/dalie/dalia-venice/","https://onlinegarden.it/products/dalia-venice-1-bulbo-da-fiore-scenografico"]]);
